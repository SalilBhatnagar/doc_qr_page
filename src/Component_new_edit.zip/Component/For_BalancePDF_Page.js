import React from 'react'

export default function For_BalancePDF_Page() {
  return (
    <div>
        <div>
        <embed src="http://localhost:3001/pdf/balance_PDF.pdf" width="100%" height="2100px" />
        </div>
    </div>
  )
}
