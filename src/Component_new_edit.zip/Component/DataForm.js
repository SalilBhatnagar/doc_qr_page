import React,{useState,useEffect} from "react";
import { useForm } from "react-hook-form";
import { useHistory, useLocation } from 'react-router-dom';



function DataForm(props) {
  let query = useQuery();
  const [stringRadio, setStringradio]= useState("true");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("")
  const [contact, setContact] = useState("");
  const [optinWhatsapp_email, setoptinWhatsapp_email] = useState(1);
  const [urlQ, setUrlQ] = useState({
   product :query.get('product'),
   utm_medium :query.get('utm_medium'),
   therapy :query.get('therapy'),
   subcategory :query.get('subcategory'),
   utm_source:query.get('utm_source')
})


  useEffect(()=>{
    // console.log(urlQ)
    // console.log("this it the product1`23",query.get('product'))
    // console.log("radiovalue", stringRadio)
    if(optinWhatsapp_email === true){ setoptinWhatsapp_email(1)}
    if(optinWhatsapp_email === false){ setoptinWhatsapp_email(0)}
    },[ optinWhatsapp_email]);
  
   const history = useHistory();

      useEffect(()=>{
        getData()
        console.log(setoptinWhatsapp_email);
      },[optinWhatsapp_email])

      function useQuery() {
        const { search } = useLocation();
      
        return React.useMemo(() => new URLSearchParams(search), [search]);
      }

      function getData(){
        console.log("this is therapy:",query.get('therapy'))
        console.log("this is utmSource",query.get('utm_source'))
        console.log("this is subcat:",query.get('subcategory'))
      }



   const handleSubmit=(e)=>{
    console.log(name, contact, email, optinWhatsapp_email, urlQ)
    e.preventDefault();
    fetch("https://kapiva.app/api/4balance_lead.php?p=4balance_lead",{

      method:'POST',
    
      body: JSON.stringify({
        "customer_name": name,
        "mobile":contact,
        "email":email,
        "optin_whatsapp_email":parseInt(optinWhatsapp_email),
        "product":String(urlQ.product),
        "therapy":String(urlQ.therapy),
        "subcategory":String(urlQ.subcategory),
        "utm_medium":String(urlQ.utm_medium),
        "utm_source":String(urlQ.utm_source)
    }),
    headers:{
      'Accept':'application/json',
      'Content-Type':'application/json'
  },
  })
  .then(res=>{res.json()})
  .then((result)=>{
     //history.push('/For_BalancePDF');

       
  }).catch((error)=>{
      alert('Faild');
  })
}



  // const {
  //   register,
  //   handleSubmit,
  //   formState: { errors },
  // } = useForm();
  
  // const onSubmit = () => {
  //   // console.log(name, email, contact, whatsapp);
      
  // };

  return (
    <div className="container">
      {/* <form  class="row"> */}

      <div class="col">
        {/* username */}
          <input onChange={(e)=>setName(e.target.value)} 
              // {...register("firstName", {
              // required: true,
              // maxLength: 20,
              // pattern: /^[A-Za-z]+$/i
              
              // })}
              type="text"
              class="form-control"
              placeholder="First name"
              aria-label="First name"
              
              />
              {/* <span>
              {errors?.firstName?.type === "required" &&
              <p class="alert alert-danger p-firstname" role="alert"> This field is required</p>
              }

              {errors?.firstName?.type === "maxLength" && (
              <p class="alert alert-danger p-firstname" role="alert">First name cannot exceed 20 characters</p>
              )}

              {errors?.firstName?.type === "pattern" && (
              <p class="alert alert-danger p-firstname" role="alert">Alphabetical characters only</p>
              )}
              
              </span> */}
              {/* <div class="alert alert-danger" role="alert">
              This is a danger alert—check it out!
              </div> */}
            <div class="valid-feedback">Looks good!</div>
            <div class="invalid-feedback">Please choose a username.</div>
          </div>
        {/* end user name  */}

        <div className="form-flex">
          <div class="col">
            <input onChange={(e)=>setEmail(e.target.value)} 
              type="email"
              class="form-control"
              placeholder="Email"
              aria-label="Email"
              //   onChange={(event) => validEmail(event)}
              // {...register("mail", {
              //   required: true,
              //   pattern: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
              //   message: "invalid email address",
              // })}
            />
            {/* <span>
              {errors?.mail?.type === "required" && (
                <p class="alert alert-danger p-email" role="alert">
                  This field is required
                </p>
              )}
              {errors?.mail?.type === "pattern" && (
                <p class="alert alert-danger p-email" role="alert">
                  Invalid Email id
                </p>
              )}
            </span> */}
          </div>
          <div class="col">
            <input onChange={(e)=>setContact(e.target.value)} 
              type="number"
              class="form-control"
              placeholder="Contact"
              aria-label="Contact"
              minLength={10}
              // {...register("number", { required: true, pattern: /[0-9]{10}/ })}
            />
            {/* <span>
              {errors?.number?.type === "required" && (
                <p class="alert alert-danger p-number" role="alert">
                  This field is required
                </p>
              )}
              {errors.number?.type === "pattern" && (
                <p class="alert alert-danger p-number" role="alert">
                  10 digit only{" "}
                </p>
              )}
            </span> */}
          </div>
        </div>
        <div className="wp-content">
       
          {/* <input type="radio" name="whatsapp" checked={optinWhatsapp_email}
             onClick={(e)=>{console.log(stringRadio)
             setoptinWhatsapp_email(!optinWhatsapp_email)
                if(optinWhatsapp_email){
                  setStringradio("true")
                }else{
                  setStringradio("false")
                }
             }}/>poinrter
          <label htmlFor="whatsapp">
            Get updates on{" "}
            <span style={{ textDecoration: "underline" }} className="green">
              WhatsApp
            </span>
            . You may opt out anytime
          </label> */}

          <div className="wp-content">
          <input type="checkbox"
           name="whatsapp"
           id="whatsapp" 
           style={{
            appearance: "auto"
           }}
           checked={optinWhatsapp_email}
           onClick={(e)=>{console.log("checkbox value",optinWhatsapp_email)
           setoptinWhatsapp_email(!optinWhatsapp_email)
                if(optinWhatsapp_email){
                  setStringradio("true")
                }else{
                  setStringradio("false")
                }
             }}
              
          />
          <label htmlFor="whatsapp">
            Get updates on{" "}
            <span style={{ textDecoration: "underline" }} className="green">
              WhatsApp
            </span>
            . You may opt out anytime
          </label>
        </div>

          {/* <input type="checkbox" id="scales" name="whatsapp"
             checked={optinWhatsapp_email}
             onClick={(e)=>{console.log(stringRadio)
             setoptinWhatsapp_email(!optinWhatsapp_email)
                if(optinWhatsapp_email){
                  setStringradio("true")
                }else{
                  setStringradio("false")
                }
             }}
             />
      <label for="scales">WhatsApp</label> */}



        </div>
        <div class="col-12">
          <input type="Submit" value="VIEW FOR FREE" 
           onClick={(e)=>handleSubmit(e)}/>
        </div>
      {/* </form> */}
    </div>
  );
}

export default DataForm;
